package com.example.demo

import android.Manifest
import android.annotation.SuppressLint
import android.content.ContentValues
import android.content.pm.PackageManager
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.*
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import kotlin.math.sqrt

class MainActivity : AppCompatActivity(), SensorEventListener {

    // ---------- Sensores ----------
    private lateinit var sensorManager: SensorManager
    private var acelerometro: Sensor? = null
    private var luz: Sensor? = null
    private var abanadelas = 0
    private var ultimaAbanadela = 0L

    // ---------- Câmara ----------
    private var fotoUri: Uri? = null
    private var aposPermissaoCamara: (() -> Unit)? = null

    // ---------- Contratos (registados antes de a Activity arrancar) ----------
    private val pedirLocalizacao = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { mapa ->
        val precisa = mapa[Manifest.permission.ACCESS_FINE_LOCATION] == true
        val aproximada = mapa[Manifest.permission.ACCESS_COARSE_LOCATION] == true
        when {
            precisa -> obterPosicao(Priority.PRIORITY_HIGH_ACCURACY)
            aproximada -> obterPosicao(Priority.PRIORITY_BALANCED_POWER_ACCURACY)
            else -> findViewById<TextView>(R.id.txtLoc).text =
                "Permissão recusada: a app continua a funcionar sem localização."
        }
    }

    private val pedirCamara = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { concedida ->
        if (concedida) aposPermissaoCamara?.invoke()
        else Toast.makeText(this, "Câmara recusada", Toast.LENGTH_SHORT).show()
        aposPermissaoCamara = null
    }

    private val tirarFoto = registerForActivityResult(
        ActivityResultContracts.TakePicture()
    ) { ok ->
        val img = findViewById<ImageView>(R.id.imgFoto)
        if (ok) img.setImageURI(fotoUri)
        else fotoUri?.let { contentResolver.delete(it, null, null) } // apaga entrada vazia
    }

    private val escolherFoto = registerForActivityResult(
        ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) findViewById<ImageView>(R.id.imgFoto).setImageURI(uri)
        else Toast.makeText(this, "Nenhuma foto escolhida", Toast.LENGTH_SHORT).show()
    }

    private val abrirDoc = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let {
            contentResolver.openInputStream(it)?.bufferedReader()?.use { r ->
                findViewById<EditText>(R.id.edtTexto).setText(r.readText())
            }
        }
    }

    private val criarDoc = registerForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        uri?.let {
            val texto = findViewById<EditText>(R.id.edtTexto).text.toString()
            contentResolver.openOutputStream(it)?.use { out -> out.write(texto.toByteArray()) }
            Toast.makeText(this, "Ficheiro guardado", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        acelerometro = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        luz = sensorManager.getDefaultSensor(Sensor.TYPE_LIGHT)
        if (luz == null) findViewById<TextView>(R.id.txtLuz).text = "Luz: sensor indisponível"

        findViewById<Button>(R.id.btnLoc).setOnClickListener {
            pedirLocalizacao.launch(
                arrayOf(
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION
                )
            )
        }
        findViewById<Button>(R.id.btnCamSistema).setOnClickListener {
            comPermissaoCamara { abrirCamaraSistema() }
        }
        findViewById<Button>(R.id.btnCameraX).setOnClickListener {
            comPermissaoCamara { iniciarCameraX() }
        }
        findViewById<Button>(R.id.btnPicker).setOnClickListener {
            escolherFoto.launch(
                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
            )
        }
        findViewById<Button>(R.id.btnAbrir).setOnClickListener {
            abrirDoc.launch(arrayOf("text/plain"))
        }
        findViewById<Button>(R.id.btnGuardar).setOnClickListener {
            criarDoc.launch("nota.txt")
        }
    }

    // ---------- Sensores: registar em onResume, desregistar em onPause ----------
    override fun onResume() {
        super.onResume()
        acelerometro?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
        luz?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_NORMAL) }
    }

    override fun onPause() {
        super.onPause()
        sensorManager.unregisterListener(this)
    }

    override fun onSensorChanged(event: SensorEvent) {
        when (event.sensor.type) {
            Sensor.TYPE_ACCELEROMETER -> {
                val (x, y, z) = event.values
                val modulo = sqrt(x * x + y * y + z * z)
                findViewById<TextView>(R.id.txtAcel).text =
                    "Acelerómetro: x=%.2f y=%.2f z=%.2f | módulo=%.2f m/s²".format(x, y, z, modulo)
                val agora = System.currentTimeMillis()
                if (modulo > 15 && agora - ultimaAbanadela > 1000) {
                    ultimaAbanadela = agora
                    agitou()
                }
            }
            Sensor.TYPE_LIGHT ->
                findViewById<TextView>(R.id.txtLuz).text = "Luz: %.0f lux".format(event.values[0])
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) { /* obrigatório, vazio */ }

    private fun agitou() {
        abanadelas++
        findViewById<TextView>(R.id.txtShake).text = "Abanadelas: $abanadelas"
        Toast.makeText(this, "Abanadela detetada!", Toast.LENGTH_SHORT).show()
    }

    // ---------- Localização ----------
    @SuppressLint("MissingPermission") // permissão já verificada no callback
    private fun obterPosicao(prioridade: Int) {
        val txt = findViewById<TextView>(R.id.txtLoc)
        val cliente = LocationServices.getFusedLocationProviderClient(this)
        val tipo = if (prioridade == Priority.PRIORITY_HIGH_ACCURACY) "precisa" else "aproximada"
        cliente.getCurrentLocation(prioridade, CancellationTokenSource().token)
            .addOnSuccessListener { loc ->
                txt.text = if (loc != null)
                    "Localização $tipo\nLat: ${loc.latitude}\nLon: ${loc.longitude}"
                else "Sem localização (ative a localização do telemóvel)"
            }
    }

    // ---------- Câmara ----------
    private fun comPermissaoCamara(acao: () -> Unit) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
            == PackageManager.PERMISSION_GRANTED
        ) acao()
        else {
            aposPermissaoCamara = acao
            pedirCamara.launch(Manifest.permission.CAMERA)
        }
    }

    private fun abrirCamaraSistema() {
        findViewById<PreviewView>(R.id.previewView).visibility = View.GONE
        val valores = ContentValues().apply {
            put(MediaStore.Images.Media.DISPLAY_NAME, "demo_${System.currentTimeMillis()}.jpg")
            put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg")
            put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/DemoApp")
        }
        fotoUri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, valores)
        fotoUri?.let { tirarFoto.launch(it) }
    }

    private fun iniciarCameraX() {
        val preview = findViewById<PreviewView>(R.id.previewView)
        preview.visibility = View.VISIBLE
        val futuro = ProcessCameraProvider.getInstance(this)
        futuro.addListener({
            val provider = futuro.get()
            val caso = Preview.Builder().build().also { it.setSurfaceProvider(preview.surfaceProvider) }
            try {
                provider.unbindAll()
                provider.bindToLifecycle(this, CameraSelector.DEFAULT_BACK_CAMERA, caso)
            } catch (e: Exception) {
                Toast.makeText(this, "Erro CameraX: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }, ContextCompat.getMainExecutor(this))
    }
}